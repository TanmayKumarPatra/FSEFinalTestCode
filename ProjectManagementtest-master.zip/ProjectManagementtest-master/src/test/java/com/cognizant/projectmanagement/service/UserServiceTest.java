package com.cognizant.projectmanagement.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.validateMockitoUsage;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.projectmanagement.dao.ParentTask;
import com.cognizant.projectmanagement.dao.User;
import com.cognizant.projectmanagement.model.UserRequest;
import com.cognizant.projectmanagement.repository.ParentTaskRepository;
import com.cognizant.projectmanagement.repository.UserRepository;

public class UserServiceTest {

	@InjectMocks
	private UserService userService;

	@Mock
	private UserRepository repo;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void validate() {
		validateMockitoUsage();
	}

	@Test
	public void getAllUsersTest()

	{
		List<User> list = new ArrayList<User>();

		User taskOne = new User(1, "shobna", "vk", "EMP123");
		User taskTwo = new User(2, "shobna", "vk", "EMP123");
		User taskThree = new User(3, "shobna", "vk", "EMP123");

		list.add(taskOne);
		list.add(taskTwo);
		list.add(taskThree);

		when(repo.findAll()).thenReturn(list);

		Iterable<User> taskList = userService.findAll();

		assertEquals(3, ((List<User>) taskList).size());
		verify(repo, times(1)).findAll();
	}

	@Test

	public void updateUserTest() {

//		 User n = userRepo.findOne(user.getUserId());
//			n.setEmployeeId(user.getEmployeeId());
//			n.setFirstName(user.getFirstName());
//			n.setLastName(user.getLastName());
//			return n;

		// User u = repo.findOne(123);
		User u = new User(1, "shobna", "vk", "EMP123");
		User u1 = new User(12, "Test", "vk", "Test123");
		
		u.setFirstName(u1.getFirstName());
		u.setLastName(u1.getLastName());
		u.setEmployeeId(u1.getEmployeeId());	
		//when(userService.updateUser(u)).thenReturn(u);
		
		when(repo.findOne(123)).thenReturn(u);
		

	}

	@Test
	public void addNewUserTest() {

		User taskOne = new User(1, "shobna", "vk", "EMP123");
		// userService.addNewUser(taskOne);
		when(userService.addNewUser(taskOne)).thenReturn(taskOne);
		when(repo.save(taskOne)).thenReturn(taskOne);

		// verify(repo, times(0).save(taskOne);

		/*
		 * User n =new User();
		 * 
		 * n.setFirstName(user.getFirstName()); n.setLastName(user.getLastName());
		 * n.setEmployeeId(user.getEmployeeId()); return userRepo.save(n);
		 */

	}

	@Test
	public void gettersSetters() {
		UserRequest u = new UserRequest();
		u.setFirstName("shobana");
		u.getFirstName();
		u.setLastName("vk");
		u.getLastName();
		u.setEmployeeId("12");
		u.getEmployeeId();
	}

}
